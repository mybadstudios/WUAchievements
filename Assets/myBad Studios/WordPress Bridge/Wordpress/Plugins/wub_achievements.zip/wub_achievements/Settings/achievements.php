<?php		

function show_wub_achievements_content()
{
	if (!current_user_can('manage_wub')) {
		wp_die(__('You do not have sufficient permissions to access this page.'));
	}

	$output = '<h2>Achievements Setup</h2>';

	//See what game we are working with
	$gid = Postedi("gid");

	//first determine if there are more than 1 game id
	$games = new WubGames();
	if ($games->GameCount() == 0) {
		$output .= '<div class=error><pre>No game data found...</pre></div>';
		return $output;
	}

	//make sure we are dealing with a game, at least...
	if ($gid == 0)
		$gid = $games->GetFirstGameID();

	$games_dropdown = '<form method=post style="width:220px">'
		. '<input type=hidden name="menu_tab" value="' . MENUTAB . '">'
		. $games->GamesDropDownList($gid, FALSE, "gid", "", '', 'submit')
		. '</form><br>';

	$users_obj = new WubUsers($gid);
	$uid = Postedi("uid");

	if (isset($_POST['wub_user_action']))
	{
		switch (strtolower($_POST['wub_user_action']))
		{
			case "receive":
			case "remove":
				$badges = new WubAchievements(Postedi('gid'), Postedi('uid'));
				$badges->ToggleObtainedState(Postedi('aid'));
				break;

			case 'search':
				$users = new WubUsers();
				$user = $users->GetSingleUserByName($_POST['wub_find_user']);
				if ($user > 0)
				{
					$_POST['uid'] = $user;
					$_REQUEST['uid'] = $user;
					$uid = Postedi("uid");
				}
				break;
		}
	}

	$wub_users_list = '
		<table><tr><td>
        <form method="POST">
		<input type="hidden" name="menu_tab" value="'.MENUTAB.'">
		<input type="hidden" name="gid" value="'.$gid.'">'
		. $users_obj->DropDownList($gid, $uid, Posted('ufilter'))
        .'</form>
        </td><td>'
		. $users_obj->SearchField($gid) .'
        </td></tr></table>';


	$output .= '<table class="wub_table_striped">'
		. '<tr><td valign="top" class="wub_settings_description">'
		. 'Select Game'
		. '</td><td valign="top" class="wub_settings_values">'
		. (($games->GameCount() > 0) ? $games_dropdown : '')
		. '</td></tr>';

	$output .= '
        <tr><td valign="top" class="wub_settings_description" style="width:235px">
        Select Account Holder
        </td><td valign="top" class="wub_settings_values" style="width:632px">'.
		$wub_users_list .'
        </td></tr>';

	$output .= wub_achievement_settings($gid, $uid);
	$output .= '</table>';

	$output .= '<style>#wpfooter{ display: none !important;}';

	return $output;
}

function wub_achievement_settings($gid, $uid)
{
	$badges = new WubAchievements($gid, $uid);
    $output = '<tr><td valign="top" class="wub_settings_description">Obtained</td><td valign="top" class="wub_settings_values">';
	if ($badges->GetObtainedCount() > 0)
		$output .= $badges->ShowAchievements(false, true,130,true);
	else
        $output .= "No achievements obtained";

 	$output .= '</td></tr><tr><td valign="top" class="wub_settings_description">Locked achievements</td><td valign="top" class="wub_settings_values">';
	if ($badges->GetLockedCount() > 0)
		$output .= $badges->ShowAchievements(true, false,130,true);
	else
        $output .= "No locked achievements available";
    $output .= '</td></tr>';
    return $output;
}
