<?php

/*
Plugin Name: WordPress For Unity Bridge - Achievements
Plugin URI: https://mybadstudios.com/
Description: Create, award and display achievements
Version: 1
Author: myBad Studios
Network: true
Author URI: https://mybadstudios.com
*/

//if these values don't exist, create them. If they do, then skip creating them
function activate_wuachievements()
{
//	include_once(dirname(__FILE__) . "/../wub_login/functions.php");
}

function deactivate_wuachievements(){
	//currently don't have anything to do here...
}

function uninstall_wuachievements() {
   	//delete the tables created by this kit...
//	include_once(dirname(__FILE__) . "/../wub_login/functions.php");
}

add_action( 'admin_enqueue_scripts', 'enqueue_wub_achievements_styles' );
function enqueue_wub_achievements_styles()
{
	wp_register_style ( 'wub_achievements_stylesheet', plugins_url('wub_achievements/Settings/ach_style.css'));
	wp_enqueue_style ( 'wub_achievements_stylesheet' );
}

include_once (dirname(__FILE__) ."/settings.php");
include_once (dirname(__FILE__) ."/posttypes/wub_achievement_type.php");
include_once (dirname(__FILE__) .'/classes/WubAchievements.class.php');

register_activation_hook( __FILE__,	'activate_wuachievements'	);
register_deactivation_hook( __FILE__,	'deactivate_wuachievements'	);
register_uninstall_hook( __FILE__,	'uninstall_wuachievements'	);
