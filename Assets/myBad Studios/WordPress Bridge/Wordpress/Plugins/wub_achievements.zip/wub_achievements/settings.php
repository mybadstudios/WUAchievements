<?php
	include_once(dirname(__FILE__) . "/../wub_login/functions.php");
	include_once(dirname(__FILE__) . "/Settings/achievements.php");

	add_filter("wub_section_heading", "wub_add_achievements_menu",18,2);
	add_filter("wub_section_content", "wub_show_achievements_section", 20, 2);

	function wub_add_achievements_menu($value)
	{
		$menu_button = new WubMenuItem('Badges');
		return $value . $menu_button->GenerateMenuButton();
	}

	function wub_show_achievements_section($content)
	{
		return (MENUTAB == BADGES_CONSTANT) ? show_wub_achievements_content() : $content;
	}

add_action( 'admin_enqueue_scripts', 'enqueue_achievements_scripts' );

function enqueue_achievements_scripts()
{
	wp_register_script( 'wub_achievements_ajax_functions', plugins_url( 'js/achievements_ajax.js', __FILE__ ) );
	wp_enqueue_script( 'wub_achievements_ajax_functions' );
}
